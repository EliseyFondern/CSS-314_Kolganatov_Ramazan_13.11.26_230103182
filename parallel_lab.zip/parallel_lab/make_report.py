"""Builds lab_report_<StudentID>.md from results/*.json, logs/*.log and the source files."""
import os

from labutil import HERE, fmt_table, load, student_id


def kb(v):
    return f"{v / 1024:.1f} MB" if v >= 1024 else f"{v} KB"


def cache_cell(H, key, per_label):
    var = H.get(key + "_kb_variants")
    if not var:
        return "[fill from OS]"
    s = " / ".join(kb(v) for v in var) + f" {per_label}"
    if len(var) > 1 and key == "l1d":
        s = f"{kb(var[0])} (P-core) / {kb(var[1])} (E-core)"
    if H.get(key + "_instances", 1) > 1:
        s += f" ({H[key + '_instances']} instances, {kb(H[key + '_total_kb'])} total)"
    return s


def answer_box(hints):
    out = ["> **Facts measured by the scripts (use them in your answer):**"]
    out += [f"> - {h}" for h in hints]
    out += ["", "**Your answer:**", "", "_(write your explanation here)_", ""]
    return "\n".join(out)


def main():
    sid = student_id()
    p0, p1, p2, p3a, p3b, p4 = (load(n) for n in ("phase0", "phase1", "phase2", "phase3a", "phase3b", "phase4"))
    H = p0["hw"]
    pphys, plog, line = H["p_phys"], H["p_log"], H.get("line_bytes", 64)
    quick = any(d.get("quick") for d in (p0, p1, p2, p3a, p3b, p4))
    L = []
    w = L.append

    w(f"# Lab Report — Performance Evaluation and Optimization in Parallel Computing")
    w(f"**Student ID:** {sid}  ")
    w(f"**Platform:** {H['python']}  ")
    if quick:
        w("\n> ⚠️ **QUICK MODE RESULTS — reduced problem sizes, NOT valid for submission. Re-run without QUICK=1.**\n")

    # ------------------------------------------------------------------ 1
    w("\n## 1. Hardware Baseline & Verification Hashes\n")
    w("### 1.1 OS hardware interrogation\n")
    w(f"```\n$ {p0['os_cmd']}\n{p0['os_out'].strip()}\n```\n")
    hyb = ""
    if H.get("p_cores"):
        hyb = f" ({H['p_cores']} P-cores + {H['e_cores']} E-cores, hybrid)"
    w(fmt_table(["Hardware Parameter", "Measured Value", "Hardware Parameter", "Measured Value"], [
        ["CPU Model String", H["model"], "L1 Data Cache (per core)", cache_cell(H, "l1d", "per core")],
        ["Physical Cores (P_phys)", f"{pphys}{hyb}", "L2 Cache Size", cache_cell(H, "l2", "per instance")],
        ["Logical Threads (P_log)", plog, "L3 Cache Size (Shared)", cache_cell(H, "l3", "")],
        ["Cache Line Size (L_bytes)", f"{line} B", "Python Version & OS", H["python"]],
    ]))
    w("\n### 1.2 Phase 0 calibration (`task0_cal.py`)\n")
    w(fmt_table(["Metric", "Value"], [
        ["`mp.cpu_count()`", plog],
        ["Clock reads", f"{p0['n']:,}"],
        ["Avg `perf_counter_ns()` call latency (incl. loop)", f"{p0['lat_ns']:.4f} ns"],
        ["Empty Python loop overhead", f"{p0['loop_ns']:.4f} ns/iter"],
        ["Net clock-read cost", f"{p0['lat_ns'] - p0['loop_ns']:.4f} ns"],
        ["OS clock resolution", f"{p0['res_ns']:.4f} ns"],
    ]))
    w("\n### 1.3 Verification hashes (verbatim)\n")
    w("```")
    for d in (p0, p1, p2, p3b, p4):
        w(d["tag"])
    w("```")
    w(fmt_table(["Tag", "primary_metric", "secondary_metric"], [
        ["PHASE0", f"avg clock-read latency = {p0['lat_ns']:.4f} ns", f"clock resolution = {p0['res_ns']:.4f} ns"],
        ["PHASE1", f"median_ms(stride=1, p={pphys}) = {p1['m1']:.4f}", f"median_ms(stride=16, p={pphys}) = {p1['m16']:.4f}"],
        ["PHASE2", f"S_strong(P_log) = {p2['s_obs']:.4f}", f"S_Gustafson(P_log) = {p2['sg']:.4f}"],
        ["PHASE3", f"GFLOP/s V1 = {p3b['g1']:.4f}", f"GFLOP/s V3(BS*={p3b['bs_star']}) = {p3b['g3']:.4f}"],
        ["PHASE4", f"T_wall(block) = {p4['t_block']:.4f} ms", f"T_wall(dynamic C*={p4['c_star']}) = {p4['t_best']:.4f} ms"],
    ]))

    # ------------------------------------------------------------------ 2
    w(f"\n## 2. Phase 1 — False Sharing & Karp-Flatt Analysis\n")
    w(f"M = {p1['M']:,} total read-modify-write steps, split as M/p per process. Workers are spawned once per "
      f"configuration and released through barriers, so process start-up is excluded from the timed region.\n")
    w(f"### Table 1A — Stride sensitivity at p = P_phys = {pphys}\n")
    ta = p1["table_a"]
    w(fmt_table(["Stride (words)", "Separation (B)", "Median (ms)", "IQR (ms)", "Throughput (Mops/s)"],
                [[r["stride"], r["bytes"], f"{r['median_ms']:.2f}", f"{r['iqr_ms']:.2f}", f"{r['mops']:.2f}"] for r in ta]))
    drops = [((ta[i - 1]["median_ms"] - ta[i]["median_ms"]) / ta[i - 1]["median_ms"], ta[i]["bytes"]) for i in range(1, len(ta))]
    big_drop, at_b = max(drops)
    t8 = ta[0]["median_ms"]
    t_iso = min(r["median_ms"] for r in ta if r["bytes"] >= line)
    w(f"\n**Largest single drop:** {big_drop * 100:.1f}% when separation grows to **{at_b} B** "
      f"(cache line reported by OS: {line} B). Time at 8 B separation vs best time at ≥{line} B: "
      f"{t8:.1f} ms vs {t_iso:.1f} ms ({t8 / t_iso:.2f}× slowdown from false sharing).\n")
    w("### Table 1B — Karp-Flatt diagnostic series\n")
    rows = []
    for a, b in zip(p1["s1"], p1["s16"]):
        f = lambda r: [f"{r['median_ms']:.1f}", f"{r['S']:.3f}", f"{r['E']:.3f}", f"{r['e']:.4f}" if r["e"] is not None else "—"]
        rows.append([a["p"]] + f(a) + f(b))
    w(fmt_table(["p", "T_p s=1 (ms)", "S_p s=1", "E_p s=1", "e(p) s=1", "T_p s=16 (ms)", "S_p s=16", "E_p s=16", "e(p) s=16"], rows))
    e1 = [r["e"] for r in p1["s1"] if r["e"] is not None]
    e16 = [r["e"] for r in p1["s16"] if r["e"] is not None]
    w("\n### Forensic explanation\n")
    w(answer_box([
        f"stride=1: e(p) goes {e1[0]:.3f} → {e1[-1]:.3f}; stride=16: e(p) goes {e16[0]:.3f} → {e16[-1]:.3f}",
        f"at p={plog}: S={p1['s1'][-1]['S']:.2f} (stride 1) vs S={p1['s16'][-1]['S']:.2f} (stride 16)",
        f"stride=1 → up to {line // 8} processes write the same {line}-byte line; every store needs exclusive (M) "
        f"ownership under MESI, invalidating the other cores' copies → the line ping-pongs between L1 caches",
        "Karp-Flatt: a *rising* e(p) means overhead grows with p (coherence traffic), not a fixed serial part; "
        "a flat/small e(p) (stride=16) means the remaining loss is fixed overhead (barrier, scheduling, turbo drop)",
        "Python note: interpreter work per store (~tens of ns) hides part of the coherence cost, so the effect is "
        "smaller than in C, but still visible",
    ]))

    # ------------------------------------------------------------------ 3
    w(f"\n## 3. Phase 2 — Strong vs Weak Scaling\n")
    w(f"Stage A: serial prefix over 5% of N (12 transcendental ops/element, parent process). "
      f"Stage B: `mp.Pool(p)` (created outside the timed region), 35 FMA+sin iterations per element.\n")
    w(f"### Table 2A — Strong scaling (N = {p2['N']:,})\n")
    st = p2["strong"]
    w(fmt_table(["p", "T_p (ms)", "IQR (ms)", "T_stageA (ms)", "S_p", "E_p", "ΔS (marginal)"],
                [[r["p"], f"{r['median_ms']:.1f}", f"{r['iqr_ms']:.1f}", f"{r['stageA_ms']:.1f}", f"{r['S']:.3f}",
                  f"{r['E']:.3f}", f"{r['S'] - st[i - 1]['S']:+.3f}" if i else "—"] for i, r in enumerate(st)]))
    w(f"\n### Table 2B — Weak scaling (N0 = {p2['N0']:,} per worker)\n")
    wk = p2["weak"]
    w(fmt_table(["p", "N(p)", "T_p (ms)", "T_stageA (ms)", "E_weak", "α", "S_Gustafson"],
                [[r["p"], f"{r['N']:,}", f"{r['median_ms']:.1f}", f"{r['stageA_ms']:.1f}", f"{r['E_weak']:.3f}",
                  f"{r['alpha']:.4f}", f"{r['S_G']:.3f}"] for r in wk]))
    w("\n### Amdahl ceiling\n")
    w(fmt_table(["Quantity", "Value"], [
        ["Serial fraction s = T_stageA(1)/T_1", f"{p2['s']:.4f}"],
        ["Amdahl S_∞ = 1/s", f"{p2['s_inf']:.2f}"],
        [f"Amdahl S(P_log={plog})", f"{p2['s_amdahl_plog']:.2f}"],
        [f"Observed S(P_log={plog})", f"{p2['s_obs']:.2f}"],
        ["Observed / Amdahl", f"{p2['s_obs'] / p2['s_amdahl_plog'] * 100:.1f}%"],
        [f"Gustafson S_G(P_log)", f"{p2['sg']:.2f}"],
    ]))
    dS = {r["p"]: r["S"] - st[i - 1]["S"] for i, r in enumerate(st) if i}

    def mean_d(lo, hi):
        v = [dS[p] for p in range(lo, hi + 1) if p in dS]
        return sum(v) / len(v) if v else float("nan")

    hints = []
    regions = []
    if H.get("p_cores") and H["p_cores"] < pphys:
        pc = H["p_cores"]
        regions = [(f"P-cores (p=2..{pc})", 2, pc), (f"E-cores (p={pc + 1}..{pphys})", pc + 1, pphys)]
    else:
        regions = [(f"physical cores (p=2..{pphys})", 2, pphys)]
    if plog > pphys:
        regions.append((f"SMT/HT threads (p={pphys + 1}..{plog})", pphys + 1, plog))
    rrows = []
    base = mean_d(regions[0][1], regions[0][2])
    for name, lo, hi in regions:
        m = mean_d(lo, hi)
        rrows.append([name, f"{m:.3f}", f"{(1 - m / base) * 100:.1f}%"])
    w("\n### Marginal speedup per added worker\n")
    w(fmt_table(["Region", "Mean ΔS per added worker", "Drop vs first region"], rrows))
    if plog > pphys and (pphys + 1) in dS and pphys in dS:
        hints.append(f"exactly at the boundary: ΔS(p={pphys}) = {dS[pphys]:+.3f}, ΔS(p={pphys + 1}) = {dS[pphys + 1]:+.3f}")
    hints += [f"{n}: mean ΔS = {m}, drop {d}" for n, m, d in rrows]
    hints += [
        f"s = {p2['s']:.4f} → Amdahl allows {p2['s_amdahl_plog']:.2f}× at p={plog}; you measured {p2['s_obs']:.2f}×",
        "reasons for falling below Amdahl: P-cores run at higher clock than E-cores; turbo frequency drops as more "
        "cores are active (power/thermal limit of a laptop); pool.map dispatch/IPC; HT threads share one core's "
        "execution ports, so a 2nd thread adds only ~10-30%",
        f"weak scaling: E_weak at p={plog} = {wk[-1]['E_weak']:.3f}; S_G grows ~linearly because α stays small",
    ]
    w("\n### Analysis (Amdahl comparison + SMT / P-core→E-core inflection)\n")
    w(answer_box(hints))

    # ------------------------------------------------------------------ 4
    w(f"\n## 4. Phase 3 — Empirical Roofline & GEMM\n")
    w("### 3A — Machine ceilings\n")
    bw, peak, ridge = p3a["bw"], p3a["peak"], p3a["ridge"]
    w(fmt_table(["Quantity", "Value"], [
        [f"96 MB parallel memoryview copy, {pphys} workers (median / IQR)", f"{p3a['bw_ms']:.3f} / {p3a['bw_iqr']:.3f} ms"],
        ["**BW_sustained** = 2·96e6 / T", f"**{bw:.2f} GB/s**"],
        [f"FMA loop: {pphys} × {p3a['flops_per_worker']:,} FLOPs (median / IQR)", f"{p3a['fl_ms']:.2f} / {p3a['fl_iqr']:.2f} ms"],
        ["**P_sustained**", f"**{peak:.4f} GFLOP/s** ({peak / pphys * 1e3:.1f} MFLOP/s per core)"],
        ["**Ridge point I\\* = P/BW**", f"**{ridge:.6f} FLOP/Byte**"],
    ]))
    N = p3b["N"]
    w(f"\n### 3B — GEMM N = {N} (2N³ = {2 * N ** 3:,} FLOPs), {pphys} workers, rows split "
      f"≈{N // pphys} rows/worker\n")
    res = p3b["results"]
    l1 = H.get("l1d_kb_variants", [32])[0] * 1024
    l2 = H.get("l2_kb_variants", [1024])[0] * 1024
    trows = []
    for r in res:
        name = {1: "V1 naive i-j-k", 2: "V2 i-k-j"}.get(r["variant"], f"V3 tiled BS={r['bs']}")
        if r["variant"] == 3:
            wt = 3 * r["bs"] ** 2 * 8
            fit = "L1d" if wt <= l1 else ("L2" if wt <= l2 else "> L2")
            wcell = f"{wt / 1024:.1f} KB ({fit})"
        else:
            wcell = "—"
        err = f"{r['err']:.1e}" if r["err"] is not None else "—"
        star = " ⭐" if r["variant"] == 3 and r["bs"] == p3b["bs_star"] else ""
        trows.append([name + star, f"{r['median_ms']:.1f}", f"{r['iqr_ms']:.1f}", f"{r['gflops']:.4f}", wcell, err])
    w(fmt_table(["Variant", "Median (ms)", "IQR (ms)", "GFLOP/s", "W_tile = 3·BS²·8", "max abs diff vs V2"], trows))
    w(f"\nV3 numerically equivalent to V2 (< 1e-9) for all BS: **{p3b['all_ok']}**\n")
    bs = p3b["bs_star"]
    v2 = res[1]["gflops"]
    rl = []
    for name, I, g in (("V1 naive", 0.125, p3b["g1"]), ("V2 i-k-j", 0.125, v2), (f"V3 BS*={bs}", bs / 12, p3b["g3"])):
        att = min(peak, I * bw)
        bound = "compute (interpreter) bound" if I > ridge else "memory bound"
        rl.append([name, f"{I:.3f}", f"{att:.4f}", bound, f"{g:.4f}", f"{g / att * 100:.1f}%"])
    w("### Roofline mapping\n")
    w(fmt_table(["Kernel", "I (FLOP/B)", "Attainable = min(P, I·BW) GFLOP/s", "Regime", "Achieved GFLOP/s", "% of attainable"], rl))
    w(f"\n_V2 uses the same analytical intensity as V1 (one A and one B operand per FMA, no cross-loop reuse); "
      f"its gain comes from unit stride and removing index arithmetic, not from higher I._\n")
    w("### Cache-capacity & roofline analysis\n")
    w(answer_box([
        f"BS* = {bs}, W_tile(BS*) = {3 * bs * bs * 8 / 1024:.1f} KB vs L1d = {l1 // 1024} KB, L2 = {l2 // 1024} KB",
        f"I* = {ridge:.5f} FLOP/B is tiny, so even I=0.125 is far right of the ridge: in pure Python every variant "
        f"is bound by interpreter dispatch, not by DRAM",
        f"V1 → V2: {v2 / p3b['g1']:.2f}× (unit stride + hoisted a_ik + list comprehension instead of index math)",
        f"V2 → V3(BS*): {p3b['g3'] / v2:.2f}×; small BS lose because Python loop/slice overhead per tile dominates; "
        f"large BS amortise it — so BS* is set by *loop overhead*, not only by cache size",
        f"with {N // pphys} rows per worker, i-tiles larger than {N // pphys} are capped at {N // pphys} rows",
    ]))

    # ------------------------------------------------------------------ 5
    w(f"\n## 5. Phase 4 — Scheduling & Load Imbalance\n")
    w(f"N = {p4['N']:,} items, K(i) = 1 + ⌊(i/60)²⌋, total {p4['total_iters']:,} inner iterations, "
      f"p = P_phys = {pphys}. Each worker writes its active time into a shared `mp.Array('d', p)`; λ is taken from the median run.\n")
    names = {"block": "S1 contiguous block (static)", "cyclic": "S2 cyclic (static)"}
    tb = p4["t_block"]
    w(fmt_table(["Strategy", "T_wall (ms)", "IQR (ms)", "t_worker min / mean / max (ms)", "λ", "Speedup vs S1"],
                [[names.get(r["mode"], f"S3 dynamic C={r['chunk']}") + (" ⭐" if r["mode"] == "dynamic" and r["chunk"] == p4["c_star"] else ""),
                  f"{r['wall_ms']:.1f}", f"{r['iqr_ms']:.1f}", f"{r['t_min']:.0f} / {r['t_mean']:.0f} / {r['t_max']:.0f}",
                  f"{r['lambda']:.3f}", f"{tb / r['wall_ms']:.2f}×"] for r in p4["rows"]]))
    dyn = {r["chunk"]: r for r in p4["rows"] if r["mode"] == "dynamic"}
    blk = p4["rows"][0]
    w("\n### Trade-off analysis (C = 1 vs C = 1024, choice of C*)\n")
    w(answer_box([
        f"S1 block: λ = {blk['lambda']:.2f} — the last worker gets the heaviest items (≈{(1 - ((pphys - 1) / pphys) ** 3) * 100:.0f}% of all work for 1/{pphys} of the items)",
        f"C=1: T={dyn[1]['wall_ms']:.0f} ms, λ={dyn[1]['lambda']:.3f} — perfect balance but {p4['N']:,} lock acquisitions; "
        f"the counter's cache line bounces between all {pphys} cores (the same contention as Phase 1)",
        f"C=1024: T={dyn[1024]['wall_ms']:.0f} ms, λ={dyn[1024]['lambda']:.3f} — only {-(-p4['N'] // 1024)} chunks for {pphys} workers; "
        f"the last chunks (heaviest items) create a long tail",
        f"C* = {p4['c_star']}: T={p4['t_best']:.0f} ms ({tb / p4['t_best']:.2f}× faster than block static)",
        "on a hybrid CPU, static schedules also suffer because E-cores are slower than P-cores — dynamic scheduling adapts to it automatically",
    ]))

    # ------------------------------------------------------------------ logs + code
    w("\n## Appendix A — Raw terminal telemetry logs\n")
    for lg in ("task0_cal", "task1_falsesharing", "task2_scaling", "task3a_roofline", "task3b_gemm", "task4_scheduling"):
        p = os.path.join(HERE, "logs", lg + ".log")
        if os.path.exists(p):
            w(f"### {lg}.log\n```\n{open(p, encoding='utf-8').read().rstrip()}\n```\n")
    w("\n## Appendix B — Python 3 source code\n")
    for src in ("harness.py", "labutil.py", "task0_cal.py", "task1_falsesharing.py", "task2_scaling.py",
                "task3a_roofline.py", "task3b_gemm.py", "task4_scheduling.py", "run_all.py", "make_report.py"):
        w(f"### {src}\n```python\n{open(os.path.join(HERE, src), encoding='utf-8').read().rstrip()}\n```\n")

    out = os.path.join(HERE, f"lab_report_{sid}.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print(f"Report written: {out}")


if __name__ == "__main__":
    main()
