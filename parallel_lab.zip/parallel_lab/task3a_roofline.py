"""Phase 3A: empirical machine Roofline - DRAM bandwidth + Python FMA compute ceiling."""
import time
from multiprocessing import shared_memory

from harness import run_benchmark
from labutil import QUICK, WorkerGroup, hw, save, student_id

BUF_BYTES = 96_000_000                  # 96 MB per buffer (192 MB total > L3)
FLOPS_PER_WORKER = 8_000_000 if QUICK else 80_000_000
WARMUP, TIMED = (1, 3) if QUICK else (2, 7)

_attached = {}


def _view(name):
    if name not in _attached:            # attach once per worker process
        s = shared_memory.SharedMemory(name=name)
        _attached[name] = (s, s.buf)
    return _attached[name][1]


def bw_worker(name_a: str, name_b: str, start: int, end: int) -> None:
    mv_a, mv_b = _view(name_a), _view(name_b)
    mv_a[start:end] = mv_b[start:end]    # native memcpy: 1 read + 1 write per byte


def flop_worker(iters: int) -> None:
    a, b = 0.9999999, 1e-7
    x0 = x1 = x2 = x3 = x4 = x5 = x6 = x7 = 1.0
    x8 = x9 = x10 = x11 = x12 = x13 = x14 = x15 = 1.0
    for _ in range(iters):               # 16 independent FMAs = 32 FLOPs / iteration
        x0 = x0 * a + b; x1 = x1 * a + b; x2 = x2 * a + b; x3 = x3 * a + b
        x4 = x4 * a + b; x5 = x5 * a + b; x6 = x6 * a + b; x7 = x7 * a + b
        x8 = x8 * a + b; x9 = x9 * a + b; x10 = x10 * a + b; x11 = x11 * a + b
        x12 = x12 * a + b; x13 = x13 * a + b; x14 = x14 * a + b; x15 = x15 * a + b


def main():
    student_id()
    H = hw()
    P = H["p_phys"]
    print(f"== Phase 3A: Roofline on P_phys = {P} workers ==")

    A = shared_memory.SharedMemory(create=True, size=BUF_BYTES)
    B = shared_memory.SharedMemory(create=True, size=BUF_BYTES)
    try:
        chunk = 1 << 20
        pattern = bytes(range(256)) * (chunk // 256)
        for off in range(0, BUF_BYTES, chunk):        # touch every page of both buffers
            n = min(chunk, BUF_BYTES - off)
            B.buf[off:off + n] = pattern[:n]
            A.buf[off:off + n] = bytes(n)
        bounds = [(t * BUF_BYTES) // P for t in range(P + 1)]
        args = [(A.name, B.name, bounds[t], bounds[t + 1]) for t in range(P)]
        with WorkerGroup(bw_worker, args) as g:
            st_bw = run_benchmark(g.run, warmup_runs=WARMUP + 1, timed_runs=TIMED)
        ok = bytes(A.buf[:4096]) == bytes(B.buf[:4096]) and bytes(A.buf[-4096:]) == bytes(B.buf[-4096:])
    finally:
        A.close(); A.unlink(); B.close(); B.unlink()
    bw = 2 * BUF_BYTES / (st_bw.median_ms / 1e3) / 1e9
    print(f"  copy 96 MB: median={st_bw.median_ms:.3f} ms IQR={st_bw.iqr_ms:.3f} ms  "
          f"-> BW_sustained = {bw:.2f} GB/s   (copy verified: {ok})")

    iters = FLOPS_PER_WORKER // 32
    with WorkerGroup(flop_worker, [(iters,)] * P) as g:
        st_fl = run_benchmark(g.run, warmup_runs=1, timed_runs=TIMED)
    total_flops = P * iters * 32
    peak = total_flops / (st_fl.median_ms / 1e3) / 1e9
    print(f"  FMA loop: {P} x {iters*32:,} FLOPs  median={st_fl.median_ms:.2f} ms IQR={st_fl.iqr_ms:.2f} ms"
          f"  -> P_sustained = {peak:.4f} GFLOP/s  ({peak / P * 1e3:.1f} MFLOP/s per core)")
    ridge = peak / bw
    print(f"  Ridge point I* = P/BW = {ridge:.6f} FLOP/Byte")
    save("phase3a", {"bw_ms": st_bw.median_ms, "bw_iqr": st_bw.iqr_ms, "bw": bw, "copy_ok": ok,
                     "fl_ms": st_fl.median_ms, "fl_iqr": st_fl.iqr_ms, "peak": peak,
                     "flops_per_worker": iters * 32, "ridge": ridge, "quick": QUICK})


if __name__ == "__main__":
    main()
