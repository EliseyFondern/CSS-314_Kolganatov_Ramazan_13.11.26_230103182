"""Phase 1: false sharing / cache-line contention + Karp-Flatt metric."""
import ctypes
import multiprocessing as mp
from multiprocessing import shared_memory

from harness import emit_verify_tag, run_benchmark
from labutil import QUICK, WorkerGroup, hw, save, student_id

M_TOTAL = 2_400_000 if QUICK else 24_000_000
WARMUP, TIMED = (1, 3) if QUICK else (2, 7)


def fs_worker(shm_name: str, slot_idx: int, iters: int) -> None:
    shm = shared_memory.SharedMemory(name=shm_name)
    # Spec uses c_uint64 * 512 (4096 B). With P_phys > 16 and stride 32 the slots
    # exceed 512 words, so the array length follows the actual buffer size.
    arr = (ctypes.c_uint64 * (len(shm.buf) // 8)).from_buffer(shm.buf)
    acc = arr[slot_idx]
    mask = 0xFFFFFFFFFFFFFFFF
    mult = 6364136223846793005
    for i in range(iters):
        acc = (acc * mult + (i | 1)) & mask
        arr[slot_idx] = acc  # Direct hardware store to shared L1 cache line
    del arr                  # Release buffer export before closing SharedMemory
    shm.close()


def measure(p: int, stride: int):
    size = max(4096, p * stride * 8 + 64)
    shm = shared_memory.SharedMemory(create=True, size=size)
    try:
        iters = M_TOTAL // p
        args = [(shm.name, t * stride, iters) for t in range(p)]
        with WorkerGroup(fs_worker, args) as g:
            st = run_benchmark(g.run, warmup_runs=WARMUP, timed_runs=TIMED)
    finally:
        shm.close()
        shm.unlink()
    mops = (iters * p) / (st.median_ms / 1e3) / 1e6
    print(f"  p={p:3d} stride={stride:3d} ({stride*8:4d} B)  median={st.median_ms:10.2f} ms  "
          f"IQR={st.iqr_ms:8.2f} ms  {mops:8.2f} Mops/s", flush=True)
    return {"p": p, "stride": stride, "bytes": stride * 8, "median_ms": st.median_ms,
            "iqr_ms": st.iqr_ms, "min_ms": st.min_ms, "max_ms": st.max_ms, "mops": mops}


def karp_flatt(rows):
    t1 = rows[0]["median_ms"]
    for r in rows:
        p = r["p"]
        r["S"] = t1 / r["median_ms"]
        r["E"] = r["S"] / p
        r["e"] = ((1 / r["S"] - 1 / p) / (1 - 1 / p)) if p >= 2 else None
    return rows


def main():
    sid = student_id()
    H = hw()
    pphys, plog = H["p_phys"], H["p_log"]
    print(f"== Phase 1: false sharing  (M={M_TOTAL:,}, P_phys={pphys}, P_log={plog}) ==")

    print(f"\n[1A] stride sweep at p = P_phys = {pphys}")
    table_a = [measure(pphys, s) for s in (1, 2, 4, 8, 16, 32)]

    plist = []
    p = 1
    while p < plog:
        plist.append(p)
        p *= 2
    plist.append(plog)
    if pphys not in plist:
        plist = sorted(set(plist + [pphys]))
    series = {}
    for stride in (1, 16):
        print(f"\n[1B] process scaling sweep stride={stride}: p in {plist}")
        series[stride] = karp_flatt([measure(p, stride) for p in plist])
        for r in series[stride]:
            e = f"{r['e']:.4f}" if r["e"] is not None else "  -   "
            print(f"    p={r['p']:3d}  S={r['S']:6.3f}  E={r['E']:6.3f}  e(p)={e}")

    m1 = next(r["median_ms"] for r in table_a if r["stride"] == 1)
    m16 = next(r["median_ms"] for r in table_a if r["stride"] == 16)
    tag = emit_verify_tag("PHASE1", sid, m1, m16)
    print(f"\n[hash inputs: median_ms(stride=1,p={pphys})={m1:.4f}, median_ms(stride=16,p={pphys})={m16:.4f}]")
    print(tag)
    save("phase1", {"M": M_TOTAL, "table_a": table_a, "s1": series[1], "s16": series[16],
                    "m1": m1, "m16": m16, "tag": tag, "quick": QUICK})


if __name__ == "__main__":
    main()
