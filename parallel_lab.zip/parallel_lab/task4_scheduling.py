"""Phase 4: skewed workload - static block vs cyclic vs shared-memory dynamic chunks."""
import math
import multiprocessing as mp
import time

from harness import emit_verify_tag, run_benchmark
from labutil import QUICK, WorkerGroup, hw, save, student_id

N_ITEMS = 4_000 if QUICK else 12_000
CHUNKS = [1, 4, 16, 64, 256, 1024]
WARMUP, TIMED = (1, 3) if QUICK else (1, 5)


def item(i: int) -> float:
    k = 1 + (i * i) // 3600            # K(i) = 1 + floor((i/60)^2)
    sin, cos, sqrt = math.sin, math.cos, math.sqrt
    x = i * 1e-4
    for _ in range(k):
        x = sin(x) + cos(x) * 0.5 + sqrt(x * x + 1.0) * 1e-3
    return x


def worker(t, p, mode, chunk, counter, wtime, wcount, wsum):
    t0 = time.perf_counter_ns()
    s, cnt = 0.0, 0
    if mode == "block":
        for i in range(t * N_ITEMS // p, (t + 1) * N_ITEMS // p):
            s += item(i); cnt += 1
    elif mode == "cyclic":
        for i in range(t, N_ITEMS, p):
            s += item(i); cnt += 1
    else:  # dynamic chunk queue on a shared, lock-protected counter
        lock = counter.get_lock()
        while True:
            with lock:
                start = counter.value
                counter.value = start + chunk
            if start >= N_ITEMS:
                break
            for i in range(start, min(start + chunk, N_ITEMS)):
                s += item(i); cnt += 1
    wtime[t] = (time.perf_counter_ns() - t0) / 1e6
    wcount[t] = cnt
    wsum[t] = s


def measure(p, mode, chunk=0):
    counter = mp.Value("i", 0)
    wtime = mp.Array("d", p)
    wcount = mp.Array("i", p)
    wsum = mp.Array("d", p)
    runs = []

    with WorkerGroup(worker, [(t, p, mode, chunk, counter, wtime, wcount, wsum) for t in range(p)]) as g:
        def fn():
            counter.value = 0
            t0 = time.perf_counter_ns()
            g.run()
            wall = (time.perf_counter_ns() - t0) / 1e6
            runs.append((wall, list(wtime), sum(wcount), sum(wsum)))
        st = run_benchmark(fn, warmup_runs=WARMUP, timed_runs=TIMED)

    timed = sorted(runs[WARMUP:], key=lambda r: r[0])
    wall, times, total_items, chk = timed[len(timed) // 2]      # the median run
    lam = max(times) / (sum(times) / p)
    return {"mode": mode, "chunk": chunk, "wall_ms": st.median_ms, "iqr_ms": st.iqr_ms,
            "lambda": lam, "t_max": max(times), "t_min": min(times), "t_mean": sum(times) / p,
            "worker_ms": times, "items": total_items, "checksum": chk}


def main():
    sid = student_id()
    H = hw()
    P = H["p_phys"]
    total_iters = sum(1 + (i * i) // 3600 for i in range(N_ITEMS))
    print(f"== Phase 4: skewed workload N={N_ITEMS:,}, total inner iterations={total_iters:,}, "
          f"K(N-1)/K(0)={1 + ((N_ITEMS-1)**2)//3600}x, p=P_phys={P} ==")
    rows = []
    for mode, chunk in [("block", 0), ("cyclic", 0)] + [("dynamic", c) for c in CHUNKS]:
        r = measure(P, mode, chunk)
        rows.append(r)
        name = mode + (f" C={chunk}" if mode == "dynamic" else "")
        print(f"  {name:14s} T_wall={r['wall_ms']:10.2f} ms  IQR={r['iqr_ms']:8.2f}  lambda={r['lambda']:.3f}  "
              f"t_worker min/mean/max={r['t_min']:.0f}/{r['t_mean']:.0f}/{r['t_max']:.0f} ms  "
              f"items={r['items']}  checksum={r['checksum']:.6f}", flush=True)
    assert all(r["items"] == N_ITEMS for r in rows), "some items were lost or duplicated!"
    dyn = [r for r in rows if r["mode"] == "dynamic"]
    best = min(dyn, key=lambda r: r["wall_ms"])
    t1 = rows[0]["wall_ms"]
    print(f"\nC* = {best['chunk']}  (T_wall={best['wall_ms']:.2f} ms, {t1 / best['wall_ms']:.2f}x faster than block static)")
    tag = emit_verify_tag("PHASE4", sid, t1, best["wall_ms"])
    print(f"[hash inputs: T_wall(block)={t1:.4f}, T_wall(dynamic C*={best['chunk']})={best['wall_ms']:.4f}]")
    print(tag)
    save("phase4", {"N": N_ITEMS, "total_iters": total_iters, "rows": rows, "c_star": best["chunk"],
                    "t_block": t1, "t_best": best["wall_ms"], "tag": tag, "quick": QUICK})


if __name__ == "__main__":
    main()
