"""Shared helpers for the lab: student ID, hardware config, result storage,
and a persistent worker group (processes are spawned ONCE per configuration and
then triggered through barriers, so Windows/macOS `spawn` start-up cost
(~0.5-2 s for 24+ processes) never pollutes the timed kernel region)."""
import json
import multiprocessing as mp
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(HERE, "results")

# QUICK=1 shrinks every problem size for a smoke test. NOT valid for submission.
QUICK = os.environ.get("QUICK", "0") == "1"

# Use the same process start method everywhere (Windows/macOS default) so results are comparable.
if os.environ.get("SPAWN", "1") == "1":
    try:
        mp.set_start_method("spawn", force=True)
    except RuntimeError:
        pass


def student_id() -> int:
    sid = os.environ.get("STUDENT_ID")
    if not sid:
        p = os.path.join(HERE, "student_id.txt")
        if os.path.exists(p):
            sid = open(p, encoding="utf-8").read().strip()
    if not sid:
        sid = input("Enter your numeric Student ID: ").strip()
        open(os.path.join(HERE, "student_id.txt"), "w", encoding="utf-8").write(sid)
    return int(sid)


def save(name: str, data: dict) -> None:
    os.makedirs(RESULTS_DIR, exist_ok=True)
    with open(os.path.join(RESULTS_DIR, f"{name}.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def load(name: str) -> dict:
    p = os.path.join(RESULTS_DIR, f"{name}.json")
    if not os.path.exists(p):
        sys.exit(f"Missing {p} - run the previous phase first.")
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def hw() -> dict:
    """Hardware parameters measured in Phase 0 (fed forward to later phases)."""
    return load("phase0")["hw"]


# ---------------------------------------------------------------- worker group
def _group_loop(target, args, start, end, stop):
    while True:
        start.wait()
        if stop.value:
            return
        target(*args)
        end.wait()


class WorkerGroup:
    """p persistent OS processes; .run() releases all of them once and returns
    when every worker has finished its kernel (barrier join)."""

    def __init__(self, target, args_list):
        n = len(args_list)
        self.start = mp.Barrier(n + 1)
        self.end = mp.Barrier(n + 1)
        self.stop = mp.Value("b", 0)
        self.procs = [
            mp.Process(target=_group_loop, args=(target, a, self.start, self.end, self.stop))
            for a in args_list
        ]
        for pr in self.procs:
            pr.start()

    def run(self):
        self.start.wait()
        self.end.wait()

    def close(self):
        self.stop.value = 1
        self.start.wait()
        for pr in self.procs:
            pr.join()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def fmt_table(headers, rows) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)
