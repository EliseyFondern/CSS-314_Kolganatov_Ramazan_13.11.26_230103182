"""Phase 0: hardware topology audit + timer noise-floor calibration."""
import json
import multiprocessing as mp
import os
import platform
import subprocess
import sys
import time

from harness import emit_verify_tag
from labutil import HERE, QUICK, save, student_id


def sh(cmd):
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30).stdout
    except Exception as e:  # noqa
        return f"<failed: {e}>"


def detect_windows(hwd):
    import ctypes
    from ctypes import wintypes

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    fn = k32.GetLogicalProcessorInformationEx
    fn.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD)]
    fn.restype = wintypes.BOOL
    n = wintypes.DWORD(0)
    fn(0xFFFF, None, ctypes.byref(n))          # RelationAll -> query size
    buf = (ctypes.c_ubyte * n.value)()
    if not fn(0xFFFF, buf, ctypes.byref(n)):
        raise OSError(ctypes.get_last_error())
    raw = bytes(buf)
    off, cores, effclass, caches = 0, 0, [], {}
    while off < n.value:
        rel = int.from_bytes(raw[off:off + 4], "little")
        size = int.from_bytes(raw[off + 4:off + 8], "little")
        d = raw[off + 8:off + size]
        if rel == 0:                            # RelationProcessorCore
            cores += 1
            effclass.append(d[1])
        elif rel == 2:                          # RelationCache
            level, line = d[0], int.from_bytes(d[2:4], "little")
            csize = int.from_bytes(d[4:8], "little")
            ctype = int.from_bytes(d[8:12], "little")  # 0 unified,1 instr,2 data
            if ctype != 1:
                caches.setdefault(level, []).append(csize)
                hwd["line_bytes"] = line
        off += size
    hwd["p_phys"] = cores
    if effclass and len(set(effclass)) > 1:
        top = max(effclass)
        hwd["p_cores"] = sum(1 for e in effclass if e == top)
        hwd["e_cores"] = cores - hwd["p_cores"]
    for lvl, key in ((1, "l1d"), (2, "l2"), (3, "l3")):
        if lvl in caches:
            sizes = sorted(set(caches[lvl]), reverse=True)
            hwd[key + "_kb_variants"] = [s // 1024 for s in sizes]
            hwd[key + "_total_kb"] = sum(caches[lvl]) // 1024
            hwd[key + "_instances"] = len(caches[lvl])


def detect_linux(hwd):
    out = sh("lscpu")
    info = {}
    for line in out.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            info[k.strip()] = v.strip()
    cps = int(info.get("Core(s) per socket", "0") or 0)
    sock = int(info.get("Socket(s)", "1") or 1)
    if cps:
        hwd["p_phys"] = cps * sock
    line = sh("getconf LEVEL1_DCACHE_LINESIZE").strip()
    if line.isdigit() and int(line) > 0:
        hwd["line_bytes"] = int(line)

    def kb(s):
        s = s.split("(")[0].strip()
        num, unit = s.split()[0], (s.split()[1] if len(s.split()) > 1 else "KiB")
        mult = {"KiB": 1, "K": 1, "MiB": 1024, "M": 1024, "GiB": 1024 * 1024}.get(unit, 1)
        return float(num) * mult

    for key, lk in (("l1d", "L1d cache"), ("l2", "L2 cache"), ("l3", "L3 cache")):
        if lk in info:
            total = kb(info[lk])
            inst = 1
            if "instance" in info[lk]:
                inst = int(info[lk].split("(")[1].split()[0])
            hwd[key + "_total_kb"] = int(total)
            hwd[key + "_instances"] = inst
            hwd[key + "_kb_variants"] = [int(total / inst)]
    if os.path.exists("/sys/devices/cpu_core/cpus") and os.path.exists("/sys/devices/cpu_atom/cpus"):
        hwd["hybrid_note"] = "Intel hybrid (cpu_core + cpu_atom) detected"


def detect_mac(hwd):
    def g(k):
        v = sh(f"sysctl -n {k}").strip()
        return int(v) if v.isdigit() else None
    hwd["p_phys"] = g("hw.physicalcpu")
    hwd["line_bytes"] = g("hw.cachelinesize") or 128
    for key, k in (("l1d", "hw.l1dcachesize"), ("l2", "hw.l2cachesize"), ("l3", "hw.l3cachesize")):
        v = g(k)
        if v:
            hwd[key + "_kb_variants"] = [v // 1024]
            hwd[key + "_total_kb"] = v // 1024
    p0, p1 = g("hw.perflevel0.physicalcpu"), g("hw.perflevel1.physicalcpu")
    if p0 and p1:
        hwd["p_cores"], hwd["e_cores"] = p0, p1


def main():
    sid = student_id()
    osname = platform.system()
    print(f"== Phase 0: hardware audit on {osname} ==")
    if osname == "Windows":
        cmd = ('powershell -NoProfile -Command "Get-CimInstance Win32_Processor | Select Name, '
               'NumberOfCores, NumberOfLogicalProcessors, L2CacheSize, L3CacheSize | Format-List"')
    elif osname == "Darwin":
        cmd = ("sysctl -n machdep.cpu.brand_string && sysctl hw.physicalcpu hw.logicalcpu "
               "hw.cachelinesize hw.l1dcachesize hw.l2cachesize hw.l3cachesize")
    else:
        cmd = ('lscpu | grep -E "Model name|Socket|Core|Thread|L1d|L2|L3" && '
               "getconf LEVEL1_DCACHE_LINESIZE")
    print(f"$ {cmd}")
    os_out = sh(cmd)
    print(os_out.strip())

    model = platform.processor()
    for line in os_out.splitlines():
        if line.strip().startswith(("Name", "Model name")) and ":" in line:
            model = line.split(":", 1)[1].strip()
    if osname == "Darwin" and os_out.strip():
        model = os_out.strip().splitlines()[0]

    hwd = {"model": model, "p_log": mp.cpu_count(), "line_bytes": 64,
           "python": f"Python {platform.python_version()} / {platform.system()} {platform.release()}"}
    try:
        {"Windows": detect_windows, "Linux": detect_linux, "Darwin": detect_mac}.get(osname, lambda h: None)(hwd)
    except Exception as e:  # noqa
        print(f"[warn] automatic topology detection failed: {e}")
    hwd.setdefault("p_phys", hwd["p_log"])

    # Manual override (edit hw_override.json if detection is wrong)
    ov = os.path.join(HERE, "hw_override.json")
    if os.path.exists(ov):
        with open(ov, encoding="utf-8") as f:
            hwd.update(json.load(f))
        print(f"[info] applied overrides from hw_override.json")

    print("\nDetected hardware parameters:")
    for k, v in hwd.items():
        print(f"  {k:18s} = {v}")

    # --- timer noise floor: 2e6 clock reads
    n = 200_000 if QUICK else 2_000_000
    pc = time.perf_counter_ns
    for _ in range(100_000):
        pc()
    t0 = pc()
    for _ in range(n):
        pc()
    t1 = pc()
    lat_ns = (t1 - t0) / n
    # empty-loop baseline so the student can see pure loop overhead
    t0 = pc()
    for _ in range(n):
        pass
    t1 = pc()
    loop_ns = (t1 - t0) / n
    res_ns = time.get_clock_info("perf_counter").resolution * 1e9
    print(f"\nmp.cpu_count()           = {mp.cpu_count()}")
    print(f"perf_counter_ns() calls   = {n}")
    print(f"avg call latency          = {lat_ns:.4f} ns  (incl. loop overhead)")
    print(f"empty loop overhead       = {loop_ns:.4f} ns/iter")
    print(f"clock resolution (OS)     = {res_ns:.4f} ns")
    tag = emit_verify_tag("PHASE0", sid, lat_ns, res_ns)
    print(f"[hash inputs: primary=avg_latency_ns={lat_ns:.4f}, secondary=clock_resolution_ns={res_ns:.4f}]")
    print(tag)
    save("phase0", {"hw": hwd, "os_cmd": cmd, "os_out": os_out, "lat_ns": lat_ns,
                    "loop_ns": loop_ns, "res_ns": res_ns, "n": n, "tag": tag, "quick": QUICK})


if __name__ == "__main__":
    main()
