"""Runs every phase in order, saving raw terminal telemetry to logs/, then builds the report.
Usage:  python run_all.py <StudentID>        (or: python run_all.py <StudentID> 2 3a  -> only those phases)"""
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PHASES = [("0", "task0_cal.py"), ("1", "task1_falsesharing.py"), ("2", "task2_scaling.py"),
          ("3a", "task3a_roofline.py"), ("3b", "task3b_gemm.py"), ("4", "task4_scheduling.py")]


def main():
    if len(sys.argv) < 2 or not sys.argv[1].isdigit():
        sys.exit("Usage: python run_all.py <numeric StudentID> [phases...]")
    sid = sys.argv[1]
    only = set(sys.argv[2:])
    with open(os.path.join(HERE, "student_id.txt"), "w", encoding="utf-8") as f:
        f.write(sid)
    os.makedirs(os.path.join(HERE, "logs"), exist_ok=True)
    env = dict(os.environ, STUDENT_ID=sid, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
    t_all = time.time()
    for key, script in PHASES:
        if only and key not in only:
            continue
        print(f"\n######## {script} ########", flush=True)
        t0 = time.time()
        log_path = os.path.join(HERE, "logs", script.replace(".py", ".log"))
        with open(log_path, "w", encoding="utf-8") as log:
            log.write(f"$ python {script}\n")
            proc = subprocess.Popen([sys.executable, os.path.join(HERE, script)], cwd=HERE, env=env,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                    encoding="utf-8")
            for line in proc.stdout:
                print(line, end="", flush=True)
                log.write(line)
            proc.wait()
        print(f"(finished in {time.time() - t0:.1f} s)")
        if proc.returncode != 0:
            sys.exit(f"{script} failed with exit code {proc.returncode} - see {log_path}")
    subprocess.run([sys.executable, os.path.join(HERE, "make_report.py")], cwd=HERE, env=env, check=True)
    print(f"\nTotal time: {(time.time() - t_all) / 60:.1f} min")


if __name__ == "__main__":
    main()
