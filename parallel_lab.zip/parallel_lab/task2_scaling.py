"""Phase 2: strong scaling (Amdahl) vs weak scaling (Gustafson)."""
import math
import multiprocessing as mp
import statistics
import time

from harness import emit_verify_tag, run_benchmark
from labutil import QUICK, hw, save, student_id

N_STRONG = 160_000 if QUICK else 1_600_000
N0_WEAK = 25_000 if QUICK else 250_000
WARMUP, TIMED = (1, 3) if QUICK else (1, 5)


def stage_a(n_serial: int) -> float:
    """Strictly serial prefix reduction: 12 transcendental ops per element
    (6 x sin + 6 x sqrt); each element depends on the running prefix value."""
    acc = 0.0
    sin, sqrt = math.sin, math.sqrt
    for i in range(n_serial):
        v = i * 1e-6 + acc * 1e-9
        for _ in range(6):
            v = sin(v) + sqrt(v * v + 1.0)
        acc += v
    return acc


def stage_b(job) -> float:
    """Embarrassingly parallel kernel: 35 FMA+trig iterations per element."""
    start, end, seed = job
    sin = math.sin
    total = 0.0
    for i in range(start, end):
        x = i * 1e-7 + seed
        for _ in range(35):
            x = sin(x * 0.999999 + 0.000001)
        total += x
    return total


def make_trial(n: int, p: int, pool, a_times: list):
    n_serial = int(0.05 * n)
    bounds = [(t * n) // p for t in range(p + 1)]

    def trial():
        t0 = time.perf_counter_ns()
        seed = stage_a(n_serial) * 1e-12
        a_times.append((time.perf_counter_ns() - t0) / 1e6)
        jobs = [(bounds[t], bounds[t + 1], seed) for t in range(p)]
        sum(pool.map(stage_b, jobs, chunksize=1))
    return trial


def run(n_of_p, plist, label):
    rows = []
    for p in plist:
        n = n_of_p(p)
        with mp.Pool(processes=p) as pool:          # created OUTSIDE the timed region
            pool.map(stage_b, [(0, 10, 0.0)] * p, chunksize=1)   # make sure all workers are up
            a_times = []
            st = run_benchmark(make_trial(n, p, pool, a_times), warmup_runs=WARMUP, timed_runs=TIMED)
        ta = statistics.median(a_times[WARMUP:])
        rows.append({"p": p, "N": n, "median_ms": st.median_ms, "iqr_ms": st.iqr_ms, "stageA_ms": ta})
        print(f"  [{label}] p={p:3d} N={n:>10,}  T={st.median_ms:10.2f} ms  IQR={st.iqr_ms:7.2f}  "
              f"T_stageA={ta:8.2f} ms", flush=True)
    return rows


def main():
    sid = student_id()
    H = hw()
    pphys, plog = H["p_phys"], H["p_log"]
    plist = list(range(1, plog + 1))
    print(f"== Phase 2: scaling  (P_phys={pphys}, P_log={plog}) ==")

    print(f"\n[2A] strong scaling, N = {N_STRONG:,}")
    strong = run(lambda p: N_STRONG, plist, "strong")
    t1 = strong[0]["median_ms"]
    for r in strong:
        r["S"] = t1 / r["median_ms"]
        r["E"] = r["S"] / r["p"]

    print(f"\n[2B] weak scaling, N0 = {N0_WEAK:,} per worker")
    weak = run(lambda p: p * N0_WEAK, plist, "weak")
    t1w = weak[0]["median_ms"]
    for r in weak:
        r["E_weak"] = t1w / r["median_ms"]
        r["alpha"] = r["stageA_ms"] / r["median_ms"]
        r["S_G"] = r["p"] - r["alpha"] * (r["p"] - 1)

    s = strong[0]["stageA_ms"] / t1
    s_inf = 1 / s
    s_amdahl_plog = 1 / (s + (1 - s) / plog)
    s_obs = strong[-1]["S"]
    sg = weak[-1]["S_G"]
    print(f"\nserial fraction s = {s:.4f}  ->  Amdahl S_inf = {s_inf:.2f}, "
          f"S_amdahl(P_log={plog}) = {s_amdahl_plog:.2f}, observed S = {s_obs:.2f}")
    for r in strong:
        print(f"  p={r['p']:3d}  S={r['S']:6.3f}  E={r['E']:6.3f}")
    print("weak:")
    for r in weak:
        print(f"  p={r['p']:3d}  E_weak={r['E_weak']:6.3f}  alpha={r['alpha']:.4f}  S_G={r['S_G']:7.3f}")
    tag = emit_verify_tag("PHASE2", sid, s_obs, sg)
    print(f"\n[hash inputs: S_strong(P_log)={s_obs:.4f}, S_Gustafson(P_log)={sg:.4f}]")
    print(tag)
    save("phase2", {"N": N_STRONG, "N0": N0_WEAK, "strong": strong, "weak": weak, "s": s,
                    "s_inf": s_inf, "s_amdahl_plog": s_amdahl_plog, "s_obs": s_obs, "sg": sg,
                    "tag": tag, "quick": QUICK})


if __name__ == "__main__":
    main()
