"""Phase 3B: progressive parallel GEMM optimization + 10-point tile-size sweep."""
import multiprocessing as mp
from array import array
from multiprocessing import shared_memory

from harness import emit_verify_tag, run_benchmark
from labutil import QUICK, hw, load, save, student_id

N = 96 if QUICK else 384
BS_LIST = [4, 8, 12, 16, 24, 32, 48, 64, 96, 128]
WARMUP, TIMED = (1, 3) if QUICK else (1, 5)

_A = _B = _C = None
_shms = []


def init_worker(na, nb, nc):
    global _A, _B, _C
    for nm in (na, nb, nc):
        _shms.append(shared_memory.SharedMemory(name=nm))
    _A, _B, _C = (s.buf.cast("d") for s in _shms)


def gemm_v1(r0, r1):
    """Naive i-j-k: B traversed with stride N, index arithmetic in the inner loop."""
    A, B, C, n = _A, _B, _C, N
    for i in range(r0, r1):
        for j in range(n):
            dot = 0.0
            for k in range(n):
                dot += A[i * n + k] * B[k * n + j]
            C[i * n + j] = dot


def gemm_v2(r0, r1):
    """i-k-j: hoist a_ik, unit-stride inner loop over contiguous rows of B and C."""
    A, B, C, n = _A, _B, _C, N
    brows = [B[k * n:(k + 1) * n].tolist() for k in range(n)]
    for i in range(r0, r1):
        base = i * n
        crow = [0.0] * n
        for k in range(n):
            aik = A[base + k]
            crow = [c + aik * b for c, b in zip(crow, brows[k])]
        C[base:base + n] = array("d", crow)


def gemm_v3(r0, r1, bs):
    """6-loop cache-blocked GEMM; micro-kernel order (i,k,j), a_ik hoisted,
    B tile slices hoisted out of the i loop and reused by every row of the tile."""
    A, B, C, n = _A, _B, _C, N
    for ii in range(r0, r1, bs):
        ie = min(ii + bs, r1)
        crows = [[0.0] * n for _ in range(ii, ie)]
        for kk in range(0, n, bs):
            ke = min(kk + bs, n)
            for jj in range(0, n, bs):
                je = min(jj + bs, n)
                btile = [B[k * n + jj:k * n + je].tolist() for k in range(kk, ke)]
                for i in range(ii, ie):
                    crow = crows[i - ii]
                    cseg = crow[jj:je]
                    base = i * n
                    for k in range(kk, ke):
                        aik = A[base + k]
                        cseg = [c + aik * b for c, b in zip(cseg, btile[k - kk])]
                    crow[jj:je] = cseg
        for i in range(ii, ie):
            C[i * n:(i + 1) * n] = array("d", crows[i - ii])


def task(job):
    variant, bs, r0, r1 = job
    if variant == 1:
        gemm_v1(r0, r1)
    elif variant == 2:
        gemm_v2(r0, r1)
    else:
        gemm_v3(r0, r1, bs)
    return True


def main():
    sid = student_id()
    H = hw()
    P = H["p_phys"]
    rf = load("phase3a")
    print(f"== Phase 3B: GEMM N={N} on P_phys={P} workers ==")

    nbytes = N * N * 8
    shms = [shared_memory.SharedMemory(create=True, size=nbytes) for _ in range(3)]
    try:
        A, B, C = (s.buf.cast("d") for s in shms)
        for idx in range(N * N):
            A[idx] = ((idx * 7) % 13) / 13.0 - 0.5
            B[idx] = ((idx * 11) % 17) / 17.0 - 0.5
        bounds = [(t * N) // P for t in range(P + 1)]
        flops = 2 * N ** 3
        results = []
        ref = None
        with mp.Pool(P, initializer=init_worker, initargs=tuple(s.name for s in shms)) as pool:
            def bench(variant, bs=0):
                jobs = [(variant, bs, bounds[t], bounds[t + 1]) for t in range(P) if bounds[t] < bounds[t + 1]]
                st = run_benchmark(lambda: pool.map(task, jobs, chunksize=1), warmup_runs=WARMUP, timed_runs=TIMED)
                return st

            for variant, bs in [(1, 0), (2, 0)] + [(3, b) for b in BS_LIST]:
                for k in range(N * N):
                    C[k] = 0.0
                st = bench(variant, bs)
                cur = C.tolist()
                err = None
                if variant == 2:
                    ref = cur
                    # spot-check V2 against a direct dot product
                    chk = max(abs(cur[i * N + j] - sum(A[i * N + k] * B[k * N + j] for k in range(N)))
                              for i, j in ((0, 0), (N // 2, N // 3), (N - 1, N - 1)))
                    err = chk
                elif ref is not None:
                    err = max(abs(x - y) for x, y in zip(cur, ref))
                g = flops / (st.median_ms / 1e3) / 1e9
                name = f"V{variant}" + (f" BS={bs}" if variant == 3 else "")
                results.append({"variant": variant, "bs": bs, "median_ms": st.median_ms,
                                "iqr_ms": st.iqr_ms, "gflops": g, "err": err})
                es = f"{err:.3e}" if err is not None else "-"
                print(f"  {name:12s} median={st.median_ms:10.2f} ms  IQR={st.iqr_ms:8.2f}  "
                      f"{g:8.4f} GFLOP/s  max|diff|={es}", flush=True)
            del A, B, C, cur, ref
    finally:
        for s in shms:
            try:
                s.close()
            except BufferError:
                pass
            s.unlink()

    v3 = [r for r in results if r["variant"] == 3]
    best = max(v3, key=lambda r: r["gflops"])
    g1 = results[0]["gflops"]
    g3 = best["gflops"]
    all_ok = all(r["err"] is not None and r["err"] < 1e-9 for r in v3)
    print(f"\nBS* = {best['bs']}  ({g3:.4f} GFLOP/s);  V3 == V2 within 1e-9 for all BS: {all_ok}")
    tag = emit_verify_tag("PHASE3", sid, g1, g3)
    print(f"[hash inputs: GFLOPs_V1={g1:.4f}, GFLOPs_V3(BS*={best['bs']})={g3:.4f}]")
    print(tag)
    save("phase3b", {"N": N, "results": results, "bs_star": best["bs"], "g1": g1, "g3": g3,
                     "all_ok": all_ok, "tag": tag, "quick": QUICK})


if __name__ == "__main__":
    main()
