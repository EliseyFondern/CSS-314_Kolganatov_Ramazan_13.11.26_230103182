import multiprocessing as mp
from multiprocessing import shared_memory
import ctypes
import time
import statistics

from harness import emit_verify_tag


# Experiment configuration
M = 16_000_000
P_PHYS = 24
P_LOG = 32

STRIDES = [1, 2, 4, 8, 16, 32]
PROCESS_COUNTS = [1, 2, 4, 8, 16, 24, 32]
RUNS = 7

MASK = 0xFFFFFFFFFFFFFFFF
MULTIPLIER = 6364136223846793005

# Replace this with your actual Student ID before the final run.
STUDENT_ID = 123456


def fs_worker(shm_name: str, slot_idx: int, iters: int) -> None:
    """Update one uint64 slot in shared memory."""
    shm = shared_memory.SharedMemory(name=shm_name)

    # The shared block can be larger than 4096 bytes for large strides.
    slot_count = shm.size // ctypes.sizeof(ctypes.c_uint64)
    arr = (ctypes.c_uint64 * slot_count).from_buffer(shm.buf)

    acc = arr[slot_idx]

    for i in range(iters):
        acc = (acc * MULTIPLIER + (i | 1)) & MASK
        arr[slot_idx] = acc

    del arr
    shm.close()


def run_experiment(p: int, stride: int) -> float:
    """Run one experiment and return wall-clock time in milliseconds."""

    # stride is measured in uint64 slots (8 bytes per slot).
    required_slots = (p - 1) * stride + 1
    shm_size = max(4096, required_slots * ctypes.sizeof(ctypes.c_uint64))

    shm = shared_memory.SharedMemory(create=True, size=shm_size)

    try:
        slot_count = shm.size // ctypes.sizeof(ctypes.c_uint64)
        arr = (ctypes.c_uint64 * slot_count).from_buffer(shm.buf)

        for i in range(slot_count):
            arr[i] = 0

        del arr

        base_iters = M // p
        remainder = M % p
        processes = []

        start = time.perf_counter_ns()

        for worker_id in range(p):
            iters = base_iters + (1 if worker_id < remainder else 0)
            slot_idx = worker_id * stride

            process = mp.Process(
                target=fs_worker,
                args=(shm.name, slot_idx, iters)
            )
            processes.append(process)
            process.start()

        for process in processes:
            process.join()

        elapsed_ms = (time.perf_counter_ns() - start) / 1e6

        failed = [
            process for process in processes
            if process.exitcode != 0
        ]
        if failed:
            raise RuntimeError(
                f"{len(failed)} worker process(es) failed; "
                f"exit codes: {[p.exitcode for p in failed]}"
            )

        return elapsed_ms

    finally:
        shm.close()
        shm.unlink()


def benchmark(p: int, stride: int):
    samples = []

    for run in range(RUNS):
        elapsed = run_experiment(p, stride)
        samples.append(elapsed)

        print(
            f"p={p}, stride={stride}, "
            f"run={run + 1}/{RUNS}: {elapsed:.2f} ms",
            flush=True
        )

    samples.sort()
    median_ms = statistics.median(samples)

    lower_half = samples[:len(samples) // 2]
    upper_half = samples[(len(samples) + 1) // 2:]
    q1 = statistics.median(lower_half)
    q3 = statistics.median(upper_half)
    iqr_ms = q3 - q1

    throughput = M / median_ms / 1000.0  # million operations/second

    return median_ms, iqr_ms, throughput


def main():
    print("PHASE 1: FALSE SHARING")
    print("======================")
    print(f"Physical cores: {P_PHYS}; logical threads: {P_LOG}")
    print(f"Total updates per experiment: {M:,}")
    print(f"Runs per configuration: {RUNS}")

    print("\nPART A: STRIDE SWEEP")
    stride_results = {}

    for stride in STRIDES:
        median, iqr, throughput = benchmark(P_PHYS, stride)
        stride_results[stride] = median

        print(
            f"SUMMARY stride={stride:2}: "
            f"median={median:.2f} ms, "
            f"IQR={iqr:.2f} ms, "
            f"throughput={throughput:.2f} Mops/s",
            flush=True
        )

    print("\nPART B: PROCESS SCALING")
    scaling_results = {}

    for stride in [1, 16]:
        scaling_results[stride] = {}
        print(f"\nStride = {stride}")

        for p in PROCESS_COUNTS:
            median, iqr, throughput = benchmark(p, stride)
            scaling_results[stride][p] = median

            print(
                f"SUMMARY processes={p:2}, stride={stride}: "
                f"median={median:.2f} ms, "
                f"IQR={iqr:.2f} ms, "
                f"throughput={throughput:.2f} Mops/s",
                flush=True
            )

    print("\nPART C: KARPF-FLATT ANALYSIS")

    for stride in [1, 16]:
        t1 = scaling_results[stride][1]
        print(f"\nStride = {stride}")

        for p in PROCESS_COUNTS:
            tp = scaling_results[stride][p]
            speedup = t1 / tp
            efficiency = speedup / p

            if p >= 2:
                karp_flatt = (
                    (1.0 / speedup) - (1.0 / p)
                ) / (1.0 - (1.0 / p))
                kf_text = f"{karp_flatt:.6f}"
            else:
                kf_text = "N/A"

            print(
                f"p={p:2}, speedup={speedup:.4f}, "
                f"efficiency={efficiency:.4f}, "
                f"Karp-Flatt={kf_text}"
            )

    verify_line = emit_verify_tag(
        "PHASE1",
        STUDENT_ID,
        stride_results[1],
        stride_results[16]
    )

    print("\nVERIFICATION")
    print(verify_line)


if __name__ == "__main__":
    mp.freeze_support()
    main()
