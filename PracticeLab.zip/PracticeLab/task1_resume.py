import multiprocessing as mp
from multiprocessing import shared_memory
import ctypes
import time
import statistics

# Continuation of Phase 1.
# Previous completed measurements are loaded from the user's terminal log.
M = 16_000_000
STRIDE = 16
PROCESS_COUNTS_TO_RUN = [8, 16, 24, 32]
RUNS = 7

MASK = 0xFFFFFFFFFFFFFFFF
MULTIPLIER = 6364136223846793005
STUDENT_ID = 123456  # Replace with your actual Student ID before final submission.

# Completed measurements from the previous run (median milliseconds).
# Stride=1: all process counts completed.
RESULTS_STRIDE_1 = {
    1: 2942.19,
    2: 1876.08,
    4: 1580.51,
    8: 2226.85,
    16: 2949.16,
    24: 2629.88,
    32: 2900.91,
}

# Stride=16: completed before the error.
RESULTS_STRIDE_16 = {
    1: 2816.17,
    2: 1793.40,
    4: 1625.36,
}


def fnv1a_hash(text: str) -> int:
    h = 14695981039346656037
    for byte in text.encode("utf-8"):
        h = ((h ^ byte) * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return h


def emit_verify_tag(phase: str, seed: int, m1: float, m2: float) -> str:
    hw = mp.cpu_count()
    signature = fnv1a_hash(
        f"{phase}|{seed}|{hw}|{m1:.4f}|{m2:.4f}"
    )
    return f"VERIFY_HASH[{phase}]: {signature:016X} (P_log={hw})"


def fs_worker(shm_name: str, slot_idx: int, iters: int) -> None:
    shm = shared_memory.SharedMemory(name=shm_name)
    slot_count = shm.size // ctypes.sizeof(ctypes.c_uint64)
    arr = (ctypes.c_uint64 * slot_count).from_buffer(shm.buf)

    acc = arr[slot_idx]
    for i in range(iters):
        acc = (acc * MULTIPLIER + (i | 1)) & MASK
        arr[slot_idx] = acc

    del arr
    shm.close()


def run_experiment(p: int, stride: int) -> float:
    required_slots = (p - 1) * stride + 1
    shm_size = max(4096, required_slots * ctypes.sizeof(ctypes.c_uint64))
    shm = shared_memory.SharedMemory(create=True, size=shm_size)

    try:
        slot_count = shm.size // ctypes.sizeof(ctypes.c_uint64)
        arr = (ctypes.c_uint64 * slot_count).from_buffer(shm.buf)
        for i in range(slot_count):
            arr[i] = 0
        del arr

        base_iters, remainder = divmod(M, p)
        processes = []
        start = time.perf_counter_ns()

        for worker_id in range(p):
            iters = base_iters + (1 if worker_id < remainder else 0)
            proc = mp.Process(
                target=fs_worker,
                args=(shm.name, worker_id * stride, iters)
            )
            processes.append(proc)
            proc.start()

        for proc in processes:
            proc.join()

        elapsed_ms = (time.perf_counter_ns() - start) / 1e6
        failures = [proc.exitcode for proc in processes if proc.exitcode != 0]
        if failures:
            raise RuntimeError(f"Worker process failure(s): {failures}")

        return elapsed_ms
    finally:
        shm.close()
        shm.unlink()


def benchmark(p: int, stride: int):
    samples = []
    for run in range(1, RUNS + 1):
        elapsed = run_experiment(p, stride)
        samples.append(elapsed)
        print(
            f"p={p}, stride={stride}, run={run}/{RUNS}: "
            f"{elapsed:.2f} ms",
            flush=True
        )

    samples.sort()
    median_ms = statistics.median(samples)
    lower = samples[:len(samples) // 2]
    upper = samples[(len(samples) + 1) // 2:]
    iqr_ms = statistics.median(upper) - statistics.median(lower)
    throughput = M / median_ms / 1000.0
    return median_ms, iqr_ms, throughput


def main():
    print("PHASE 1 CONTINUATION: STRIDE 16")
    print("Previously completed results will be reused.")
    print("The p=8 test is restarted from run 1 because its previous run failed.")

    for p in PROCESS_COUNTS_TO_RUN:
        median, iqr, throughput = benchmark(p, STRIDE)
        RESULTS_STRIDE_16[p] = median
        print(
            f"SUMMARY processes={p}, stride=16: "
            f"median={median:.2f} ms, IQR={iqr:.2f} ms, "
            f"throughput={throughput:.2f} Mops/s",
            flush=True
        )

    print("\nPART C: KARPF-FLATT ANALYSIS")
    for stride, results in [
        (1, RESULTS_STRIDE_1),
        (16, RESULTS_STRIDE_16),
    ]:
        t1 = results[1]
        print(f"\nStride = {stride}")
        for p in [1, 2, 4, 8, 16, 24, 32]:
            tp = results[p]
            speedup = t1 / tp
            efficiency = speedup / p
            if p >= 2:
                kf = ((1.0 / speedup) - (1.0 / p)) / (1.0 - (1.0 / p))
                kf_text = f"{kf:.6f}"
            else:
                kf_text = "N/A"
            print(
                f"p={p:2}, speedup={speedup:.4f}, "
                f"efficiency={efficiency:.4f}, Karp-Flatt={kf_text}"
            )

    print("\nVERIFICATION")
    print(emit_verify_tag(
        "PHASE1",
        STUDENT_ID,
        2761.01,  # Part A median for stride=1 at p=24
        2014.61   # Part A median for stride=16 at p=24
    ))


if __name__ == "__main__":
    mp.freeze_support()
    main()
