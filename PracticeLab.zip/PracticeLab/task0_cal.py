
import multiprocessing as mp
import time

from harness import emit_verify_tag


# Your Student ID (replace with your actual ID)
STUDENT_ID = 230103182

# Number of measurements
ITERATIONS = 1_000_000


def main():

    # Get the number of logical CPU threads
    cpu_count = mp.cpu_count()

    print("PHASE 0: CPU Calibration")
    print("------------------------")
    print(f"Logical CPU threads: {cpu_count}")

    # Measure 1 million consecutive timer calls
    start = time.perf_counter_ns()

    for _ in range(ITERATIONS):
        time.perf_counter_ns()

    end = time.perf_counter_ns()

    total_ns = end - start

    # Calculate average time per call
    average_ns = total_ns / ITERATIONS

    total_ms = total_ns / 1_000_000

    print(f"Total measurement time: {total_ms:.4f} ms")
    print(f"Average timer call latency: {average_ns:.4f} ns")

    # Generate verification hash
    verify = emit_verify_tag(
        "PHASE0",
        STUDENT_ID,
        average_ns,
        total_ms
    )

    print()
    print(verify)


if __name__ == "__main__":
    main()
